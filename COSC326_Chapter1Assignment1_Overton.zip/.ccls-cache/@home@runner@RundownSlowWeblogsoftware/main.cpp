#include <iostream>
#include <string>

bool isPalindrome(const std::string& w, int start, int end) {

    if (start >= end) 
        return true;
    if (w[start] != w[end]) 
        return false;
    return isPalindrome(w, start + 1, end - 1);
}

int main() {
 std::string w = "racecar";
  int n = w.size();
  if (isPalindrome(w, 0, n - 1))

    std::cout << w << " is a palindrome." << std::endl;
  else
    std::cout << w << " is not a palindrome." << std::endl;

  return 0;
  
}